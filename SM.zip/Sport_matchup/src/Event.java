public class Event {

	public int event_id;
	public int owner_id;
	public String date;
	public String time;
	public String place;
	public int all_spots;
	public int level_constraint;
	public boolean ispublic;
	public int discipline_id;

	public Event(int event_id, int owner_id, String date, String time,
			String place, int all_spots, int level_constraint,
			boolean ispublic, int discipline_id) {
		super();
		this.event_id = event_id;
		this.owner_id = owner_id;
		this.date = date;
		this.time = time;
		this.place = place;
		this.all_spots = all_spots;
		this.level_constraint = level_constraint;
		this.ispublic = ispublic;
		this.discipline_id = discipline_id;
	}

}
