import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User {

	public int id;
	public static String fname;
	public static String lname;
	private static String email;
	private static String pwd;
	public static String city;
	public static String gender;
	public static String discipline;
	public static int level;

	public User(int id, String fname, String lname, String email, String pwd,
			String city, String gender, String discipline, int level) {

		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.pwd = pwd;
		this.city = city;
		this.gender = gender;
		this.discipline = discipline;
		this.level = level;

	}

	public static User displayUserByID(int id) {
		Connection con = null;
		try {
			con = Login.createConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement("SELECT * FROM users WHERE id = ?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ps.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ResultSet rs = null;
		try {
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {

			while (rs.next()) {
				fname = rs.getString("first_name");
				lname = rs.getString("last_name");
				email = rs.getString("email");
				pwd = rs.getString("password");
				city = rs.getString("city");
				gender = rs.getString("gender");
				discipline = rs.getString("discipline");
				level = rs.getInt("level");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new User(id, fname, lname, email, pwd, city, gender, discipline,
				level);

	}

	public User displayUserByFnameAndLname(String fname, String lname) {
		Connection con = null;
		try {
			con = Login.createConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement("SELECT * FROM users WHERE fname=? AND lname=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ps.setString(1, fname);
			ps.setString(2, lname);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {

			while (rs.next()) {
				id = rs.getInt("id");
				email = rs.getString("email");
				pwd = rs.getString("password");
				city = rs.getString("city");
				gender = rs.getString("gender");
				discipline = rs.getString("discipline");
				level = rs.getInt("level");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new User(id, fname, lname, email, pwd, city, gender, discipline,
				level);

	}

	public static void registerUser(String email, String pwd, String fname,
			String lname, String city, String gender, String discipline,
			int level) {
		boolean st = false;
		try {

			// loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			// creating connection with the database
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mock_data", "root",
					"WAPsport_matchup");
			// w miejsce ? wstawiany jest email i has�o u�ytkownika, je�li
			// istnieje w bazie, zwracane jest true
			PreparedStatement ps = con
					.prepareStatement("insert into USERS (first_name, last_name, email, password, gender, city, discipline, level) values(?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4, pwd);
			ps.setString(5, gender);
			ps.setString(6, city);
			ps.setString(7, discipline);
			ps.setInt(8, level);

			boolean rs = ps.execute();
			// st = rs.next();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDiscipline() {
		return discipline;
	}

	public void setDiscipline(String discipline) {
		this.discipline = discipline;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
