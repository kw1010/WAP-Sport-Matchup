import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;

public class Login extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String email = request.getParameter("email");
		String pass = request.getParameter("pass");

		Connection con = null;
		try {
			con = createConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (checkUser(email, pass)) {

			

			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement("SELECT id, first_name, last_name FROM users WHERE email = ?");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.setString(1, email);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String n = null;
			String ln = null;
			String id = null;
			try {

				while (rs.next()) {
					n = rs.getString("first_name");
					ln = rs.getString("last_name");
					id = Integer.toString(rs.getInt("id"));

				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(60 * 60);
			session.setAttribute("id", id);
			session.setAttribute("name", n.concat(" ").concat(ln));
			
			Cookie sessionCookie = new Cookie("sessionId", session.getId());
			sessionCookie.setMaxAge(60*60);
			
			RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
			rd.forward(request, response);

		} else {
			out.println("Username or Password incorrect");
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.include(request, response);
		}

	}

	public static Connection createConnection() throws SQLException {
		// loading drivers for mysql
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// creating connection with the database
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mock_data", "root",
				"WAPsport_matchup");

		return con;

	}

	public static boolean checkUser(String email, String pass) {
		boolean st = false;
		try {

			Connection con = createConnection();
			// w miejsce ? wstawiany jest email i has�o u�ytkownika, je�li
			// istnieje w bazie, zwracane jest true
			PreparedStatement ps = con
					.prepareStatement("select * from users where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			st = rs.next();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;
	}
}