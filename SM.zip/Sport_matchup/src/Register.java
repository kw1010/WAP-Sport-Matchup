import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;

public class Register extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String email = request.getParameter("email");
		String pass = request.getParameter("pwd1");
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String city = request.getParameter("city");
		String gender = request.getParameter("gender");
		String discipline = request.getParameter("discipline");
		int level = Integer.parseInt(request.getParameter("level"));

		if (Validate.checkUser(email, pass)) {
			request.setAttribute("Error", "User already exist");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.forward(request, response);
			
		} else {
			registerUser(email, pass, fname, lname, city, gender, discipline,
					level);

			String id = null;
			try {
				boolean st = false;
				// loading drivers for mysql
				Class.forName("com.mysql.jdbc.Driver");

				// creating connection with the database
				Connection con = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/mock_data", "root",
						"WAPsport_matchup");
				// w miejsce ? wstawiany jest email i has�o u�ytkownika, je�li
				// istnieje w bazie, zwracane jest true
				PreparedStatement ps = con
						.prepareStatement("select id from users where email=?");

				ps.setString(1, email);
				ResultSet rs = ps.executeQuery();
				st = rs.next();

				while (rs.next()) {
					id = Integer.toString(rs.getInt("id"));

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(60 * 60);
			session.setAttribute("id", id);
			session.setAttribute("name", fname.concat(" ").concat(lname));

			Cookie sessionCookie = new Cookie("sessionId", session.getId());
			sessionCookie.setMaxAge(60 * 60);

			RequestDispatcher rs = request.getRequestDispatcher("welcome.jsp");
			rs.forward(request, response);
		}

	}

	public static void registerUser(String email, String pwd, String fname,
			String lname, String city, String gender, String discipline,
			int level) {
		boolean st = false;
		try {

			// loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			// creating connection with the database
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mock_data", "root",
					"WAPsport_matchup");
			// w miejsce ? wstawiany jest email i has�o u�ytkownika, je�li
			// istnieje w bazie, zwracane jest true
			PreparedStatement ps = con
					.prepareStatement("insert into USERS (first_name, last_name, email, password, gender, city, discipline, level) values(?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4, pwd);
			ps.setString(5, gender);
			ps.setString(6, city);
			ps.setString(7, discipline);
			ps.setInt(8, level);

			boolean rs = ps.execute();
			// st = rs.next();

		} catch (Exception e) {
			e.printStackTrace();
		}
		// return st;
	}
}