

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddEvent
 */
@WebServlet("/AddEvent")
public class AddEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEvent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//STR_TO_DATE('01,5,2013','%d,%m,%Y');
		
		response.setContentType("text/html;charset=UTF-8");
		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String place = request.getParameter("place");
		String discipline = request.getParameter("discipline");
		int level = Integer.parseInt(request.getParameter("level"));
		int how_many = Integer.parseInt(request.getParameter("how_many"));
		String ispublic = request.getParameter("public");
		String description = request.getParameter("description");
		
		
		boolean st = false;
		try {

			// loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			// creating connection with the database
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mock_data", "root",
					"WAPsport_matchup");
			// w miejsce ? wstawiany jest email i has�o u�ytkownika, je�li
			// istnieje w bazie, zwracane jest true
			PreparedStatement ps = con
					.prepareStatement("insert into EVENTS (owner_id, date, time, place, discipline, level_constraint, all_spots, description, public) values(?, str_to_date(?, '%Y-%m-%d'), str_to_date(?, '%H:%i'), ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, Integer.parseInt((String)request.getSession().getAttribute("id")));
			ps.setString(2, date);
			ps.setString(3, time);
			ps.setString(4, place);
			ps.setString(5, discipline);
			ps.setInt(6, level);
			ps.setInt(7, how_many);
			ps.setString(8, description);
			ps.setString(9, ispublic);
	

			boolean rs = ps.execute();
			// st = rs.next();

		} catch (Exception e) {
			e.printStackTrace();
		}
		// return st;
		
		RequestDispatcher rs = request.getRequestDispatcher("welcome.jsp");
		rs.forward(request, response);
	}

}
