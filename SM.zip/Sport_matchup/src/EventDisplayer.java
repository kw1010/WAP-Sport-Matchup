import java.sql.*;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.sql.Result;
import javax.servlet.jsp.jstl.sql.ResultSupport;

/**
 * Servlet implementation class EventDisplayer
 */
@WebServlet("/EventDisplayer")
public class EventDisplayer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EventDisplayer() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			con = Login.createConnection();
			ps = con.prepareStatement("SELECT concat(u.first_name, concat(\" \", u.last_name)) as Name, date, e.place, d.discipline, level "
					+ "from events e inner join users u on u.id = e.owner_id "
					+ "inner join disciplines d on d.discipline_id = e.discipline;");

			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("Name"));
			}
			Result result = ResultSupport.toResult(rs);
			request.setAttribute("result", result);
			RequestDispatcher rd = request
					.getRequestDispatcher("my_events.jsp");
			rd.forward(request, response);
		} catch (SQLException ex) {
			throw new ServletException(ex);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
