

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.sql.Result;
import javax.servlet.jsp.jstl.sql.ResultSupport;

/**
 * Servlet implementation class SearchEvent
 */
@WebServlet("/SearchEvent")
public class SearchEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchEvent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		int discipline = Integer.parseInt(request.getParameter("discipline"));
		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String city = request.getParameter("city");
		int level = Integer.parseInt(request.getParameter("level"));
				
		try {
			con = Login.createConnection();
			ps = con.prepareStatement("SELECT concat(u.first_name, concat(\" \", u.last_name)) as Name, date, e.place, d.discipline, level_constraint as level, event_id "
					+ "from events e inner join users u on u.id = e.owner_id "
					+ "inner join disciplines d on d.discipline_id = e.discipline " 
					+ " where date <=> ? or time <=> ? or e.place <=> ? or d.discipline_id <=> ? or e.level_constraint <=> ?;");


			ps.setInt(1, discipline);
			ps.setString(2, date);
			ps.setString(3, time);
			ps.setString(4,  city);
			ps.setInt(5, level);
			
			rs = ps.executeQuery();
			
			Result result = ResultSupport.toResult(rs);
			
			request.setAttribute("result", result);
			
			RequestDispatcher rd = request
					.getRequestDispatcher("search_event.jsp");
			rd.forward(request, response);
		} catch (SQLException ex) {
			throw new ServletException(ex);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
